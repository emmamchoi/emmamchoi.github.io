(function(){

    "use strict";
    let myForm = document.querySelector('form');
    let myArticle = document.getElementById('article1');

    myForm.addEventListener('submit', function(event){
        
        event.preventDefault();

        let formData = document.querySelectorAll('input[type = text');
        processData(formData);
        
    });

    // process data funct
    function processData(formData){
        let emptyVals = 0;
        var words = [];
        for(let word of formData){
            if(word.value){
                words.push(word.value);
                word.value = '';
            }else{
                emptyVals++;
            }
        }
        if(emptyVals > 0){
            myArticle.innerHTML = "Please enter words";
        }else{
            makeMadLib(words);
        }
    }

    // put words in madlib    
    function makeMadLib(words){
        var myText = `The ${words[0]} and ${words[1]} of ${words[2]} things ${words[3]}`;
        
        myArticle.innerHTML = myText;  

    }

 
}());